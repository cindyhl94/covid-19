model_save_path = "models/"

datasets_path = {

    "biorxiv_medrxiv" : "datasets/2020-03-13/biorxiv_medrxiv/biorxiv_medrxiv/",
    "pmc_custom_license": "datasets/2020-03-13/pmc_custom_license/pmc_custom_license/",
    "comm_use_subset" : "datasets/2020-03-13/comm_use_subset/comm_use_subset/",
    "noncomm_use_subset" : "datasets/2020-03-13/noncomm_use_subset/noncomm_use_subset/"
}



