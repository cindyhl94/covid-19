
from src.fetch_data.get_relevant_sections import get_sections

test_file = "data/arxiv/arxiv/pdf_json/92a4865e560a9dfbedc5e8fa1cfa3d095ed45f92.json"
search_string = "ethic"

test_file = "data/custom_license/custom_license/pdf_json/365e96ad16a50a5bf24966115d7f7d951894eb19.json"

grs = get_sections()

#op = grs.process_files(test_file, search_string)
op = grs.process_files()
#op = grs.process_file(test_file, search_string = "ethic")
print(op)

text = "In \u00a7 1, I review the history of Ebola and its emergence as a site of biosecurity concerns. Juxtaposing these securitisation discourses with the evolution of scientific knowledge of the virus, its taxonomy and epidemiology, I argue that by 2014 Ebola was no longer regarded as a highly pathogenic 'hot virus' and potential biothreat so much as a viral haemorrhagic fever (VHF) endemic to central Africa, and which, it was thought, could be contained by basic hygiene measures and the rapid deployment of technical experts to the foci of outbreaks. In \u00a7 2, I turn to the regulatory mechanisms and managerial procedures for the governance of Ebola and other generic biothreats. Focusing on the operation of the IHR (2005) and the ERF, I argue that the West African outbreak revealed flaws in risk triaging systems put in place after the 'false alarm' of the H1N1 swine flu outbreak in 2009. The result was that Ebola was relegated to the fringes of global health security just at the moment when the virus was crossing international borders and triggering urban outbreaks for the first time. In \u00a7 3, drawing on the work of medical anthropologists, I examine the role of rumour, panic and fear in mediating responses to the outbreak, showing how the framing of Ebola as a hot virus and security threat confused communities in the affected countries, fuelling distrust of international health responders and the biomedical messaging. At first, the terrifying popular image of Ebola also hampered the emergency response. It was only when Ebola threatened an epidemic beyond West Africa and the extent of the death and suffering within the tri-border zone became too visible to ignore, that, I argue, both the affected communities and leading global health actors responded with alacrity. Contrasting the delay over Ebola with the WHO's rapid response to the emergence of SARS and its similarly rapid declarations of public health emergencies for swine flu in 2009 and polio in 2014, I conclude that the WHO's 'failure' flowed both from Ebola's shifting medical identity and from the organisation's attempt to rationalise its response to novel emergence events -events that are unpredictable and unknowable."

#from src.nlp import phrase_matcher as pm

#if pm.find_matches([text.lower()]):
#    print("match found")


