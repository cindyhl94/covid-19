from src.nlp.get_phrases import extract_phrases

txt = """Hi how are you I'm calling from some information on a part and our current number to my phone number is 449-5969 can I please order the the lease on the orange juice for oil and the evidence speaks for tomorrow thank you. hello this is life from most Cafe Glenville the customer number is 209-6091 phone number is 469-727-5937 I just would like tomorrow five minutes of skim milk deleted 18 units of full cream milk two liters and one fixed came by players yep thank you bye. hi it's Nadia from my ship it down my customer number is 1 5 2 4 8 7 I need 1 litre bottle milk 61 little shade can buttons one little lightweight 12,300 fresh Stream 650 light sour cream eight three hundred travel cream 12500 data special three packets 500 more coverage package 300C can clean 10500 Double Espresso one package two liter skim milk six bottles that's all for today thank you. all right this is easy mop was a killer key account number 19613 and I please get their five hundred million more, it's Chris 36 and the chocolate 500ml big and chocolate 306 big and probably 300 located off today thank you bye-bye. 208-8335 can I please get six bottles of full cream two liter milk three bottles of skin two liter milk one tray of the Dairy Farmers, strawberry milk one tray of the Dead no sugar 500 mL 350 figure gets a hundred and fifty grams to lemon cream yogurt 250001 creamy vanilla yogurt a hundred and fifty grams thank you"""


txt = "Before COVID-19, internet addiction was already recognized as a growing problem contributing to social anxiety, attention deficit/hyperactivity disorder, and other aspects of wellness, which may only intensify during these trying times that are constantly reminding us of the stakes we face."


ep = extract_phrases()

op = ep.get_phrases_sgrank(txt)

print(op)

