from src.nlp.doc_sim import document_similarity

ds = document_similarity()

src = "Searching for volunteers to sew cloth face masks and scrub hats"
tgt = "sew masks and hats"
tgt1 = "pick up and drop of medicines"

score = ds.get_sent2vec_similarity(src, tgt)
print(score)
score = ds.get_sent2vec_similarity(src, tgt1)
print(score)
