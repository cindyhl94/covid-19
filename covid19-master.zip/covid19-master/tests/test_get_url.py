from src.datasources.rss_feeds import get_rss_feeds as grf
from src. datasources.rss_feeds import config

rss_op = grf.get_rss_feeds()
for url in config.urls:
    rss_op.get_webpage(url)

