from src.datasources.rss_feeds import get_rss_feeds as grf
from src. datasources.rss_feeds import config

rss_op = grf.get_rss_feeds(config.feed_urls)
rss_op.get_feed_content()
#rss_op.process_1_feed(feed_urls)

