
from src.nlp import token_matcher
from src.common.patterns import ethics

messages = [
    "my friend donna got back from anxiety and is in isolation in a motel in Mosman. She is from Moree and has 9 more days to go before she can get a home. The motel has no cooking or kitchenette facilities. She has a local place to deliver instant noodles. She would love some fresh fruit, tinned tuna and other things to break the monotony of what she has to eat. I was looking out for someone who might be able to help out. I can transfer some money before they go shopping",
    "we will provide free accommodation",
    "we will try to accommodate",
    "we will provide assistance",
    "we will provide little bit of lodging",
    "we will provide little bit of assistance in giving our boarding house and bunk beds",
    "I've got bunk beds and a bungalow",
    "we should use the govt. run student hostels",
    "road side inns available for accommodation",
    "we have a place to rent",
    "have a restaurant to deliver food"
]

#token_matcher.add_patterns([""])
token_matcher.add_patterns(ethics.patterns)
op = token_matcher.detect_patterns(messages)
print(op)

from src.nlp import phrase_matcher as pm
pm.find_matches(messages)
