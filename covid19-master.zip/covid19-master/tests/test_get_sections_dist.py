
from src.fetch_data.get_relevant_sections_dist import get_sections

grs = get_sections()
op = grs.process_files()
print(op)


