import json
from typing import Dict
import re
from src.nlp import phrase_matcher as pm
from src.common.patterns import ethics 
import dask

class get_sections(object):

    def __init__(self, search_string = None):
        if search_string is not None:
            self.search_string = search_string
        return

    def process_file(self, f, search_string):

        with open(f, "r",) as fp:
            data = json.load(fp)
            fp.close()

        self.search_string = search_string if search_string is not None else self.search_string
        op = self.search_sections(data, self.search_string)

        return op

    def search_sections(self, data:Dict, search_string:str):
        '''
        {
          "paper_id" : "",
          [
            {
              "section" : "metadata",
              "text" : [ " ", " "]
            }
         ],   
            {
            }
        }
        '''
        op = {}
        
        #op['metadata'] = data['metadata']
        op['paper_id'] = data['paper_id']
        op['matches'] = []

        match_details = {}
        #check of title contains the terms
        if pm.find_matches([data['metadata']['title'].lower()]):
        #if re.search(search_string, data['metadata']['title'].lower()):
            match_details['title'] = [ data['metadata']['title'] ]
        
        #check in abstract
        if 'abstract' in data.keys() and len(data['abstract']):
            #if re.search(search_string, data['abstract'][0]['section'].lower()):
            if pm.find_matches([data['abstract'][0]['section'].lower()]):
                match_details['abstract'] = [ data['metadata']['title'] ]

        #process body text
        match_details['body_text'] = {}
        for bt in data['body_text']:
            #if re.search(search_string, bt['text'].lower()):
            if pm.find_matches([bt['text'].lower()]):
                if bt['section'] in match_details:
                    match_details['body_text'][bt['section']].append(bt['text'])
                else:
                    match_details['body_text'][bt['section']] = [bt['text']]

        match_details['ref_entries'] = []
        for key, val in data['ref_entries'].items():
            if pm.find_matches([val['text'].lower()]):
            #if re.search(search_string, val['text'].lower()):
                match_details['ref_entries'].append(val['text'])

        #back matter
        match_details['back_matter'] = {}
        for bm in data['back_matter']:
            #if re.search(search_string, bm['text'].lower()) or re.search(search_string, bm['section'].lower()):
            if pm.find_matches([bm['text'].lower(), bm['section'].lower()]):
                match_details['back_matter'][bm['section']] = bm['text']
            
        op['matches'] = match_details
        return op
    

    
    def process_files(self):

        files = []
        with open("ethics_files.txt", "r") as fp:
            files = fp.readlines()
            fp.close()
        
        results = {}
        for f in files:
            f = f.strip()
            op = self.process_file(f, "ethic")
            results[f] = op

        with open(ethics.op_section_file, "w") as fp:
            json.dump(results, fp, indent=2)
            fp.close()
