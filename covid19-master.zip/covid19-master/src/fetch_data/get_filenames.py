import glob
import os
import re

from src.configs import config
from src.configs.ethics import fear_anxiety as fa
from src.nlp import phrase_matcher as pm
from src.fetch_data import get_relevant_sections as grs

class get_relevant_filenames(object):

    def __init__(self, match_pattern = None):

        self.grs = get_sections()
        self.task_type = "test.txt"
        self.matched_files = []
        terms = []
        term = ""
        self.dataset_path = config.datasets
        if match_pattern == "fear_anxiety":
            terms = fa.terms
            self.task_type = match_pattern
        else:
            return
        
        self.terms = terms
        self.term = "".join(self.terms)

        self.pat = re.compile(self.term)

        return


    def write_filenames(self, filenames):
        outfile = fa.matched_filenames_path + "/" + self.task_type
        with open(outfile, "w") as fp:
            fp.writelines(filenames)
        fp.close()

        return

    def fetch_filenames(self):

        for dataset in self.dataset_path:
            files = glob.glob(dataset + "/**/*.json", recursive=True)
            filenames = self.process_files(files)

            self.write_filenames(filenames)

        return
            
    def process_files(self, files):
        matched_files = []
        for f in files:
            result = self.gs.process_file(f, "ethic")
            if result:
                matched_files.append(f)

        return matched_files

    def process_file(self, f):
        with open(f, "r") as fp:
            data = fp.read()
            return pm.find_matches([data])
                
            #if self.pat.search(data):
            #fp.close()
            #return True
        fp.close()
        return False

                
