#from get_sentiment import *
#from db_services import *
from werkzeug.utils import secure_filename
from src.nlp.topic_modeling.lda_wrapper import wrap_lda_models
from src.common.fricles_logger import *
import os
from typing import List, Dict, Optional
from src.common.fricles_logger import *
from src.nlp.keyphrases.keyphrases_wrapper import keyphrase_wrapper

class wflow_manager(object):

    def __init__(self,db_name=None):
        fricles_logger.info('Initializng lda model pipeline...')
        self.lda = wrap_lda_models()
        self.kp_wrapper = keyphrase_wrapper()
        self.upload_path = "data/"
        pass

    def wf_get_sentiment_scores(self, text, api_key=None):
        scores = self.sent.calculate_sentiments(text)
        #update counter to track number of API calls
        if api_key is None:
            api_key = "free_calls"
        ret = self.dbs_api.update_api_counter("sentiment_api", api_key)

        return scores

    def wf_validate_api_key(self,api_key):
        ret = self.dbs_api.api_key_exists(api_key)
        return ret

    def get_keyphrases_from_documents(self, input_file) -> Dict:
        '''Workflow to extract key phrases
        Args:
            text (str): input text to extract keyphrases
        Returns
            results (dict): output including status message
        '''
        fricles_logger.info('Starting workflow to get keyphrases..')
        path = self.upload_path + os.path.join(input_file.filename)
        input_file.save(path)
        with open(self.upload_path + secure_filename(input_file.filename), "r") as fp:
            file_data = fp.read().strip()
        fp.close()
        text = file_data
        results = self.kp_wrapper.run_all_kp_models(text)

        return results

    def get_topics_from_documents(self, input_file, num_topics: Optional[int]=4) -> Dict:
        '''Start of workflow for topic modeling
        Args:
            input_file: input file uploaded by the user
            num_topics: number of topics input by the user
        Returns:
            results (dict): output of topics with status message
        '''
        data = ""
        try:
            fricles_logger.info('Processing user input file...')
            path = self.upload_path + os.path.join(input_file.filename)
            input_file.save(path)
            with open(self.upload_path + secure_filename(input_file.filename), "r") as fp:
                file_data = fp.read().strip()
            fp.close()
            data = file_data.split('\n')
        except Exception as e:
            fricles_logger.error('Failed to process input file :' + str(e))
            return API_FAILURE
        
        try:
            fricles_logger.info('Starting lda model wrapper...')
            results = self.lda.run_all_lda_models(data, num_topics)
        except Exception as e:
            fricles_logger.error('Failed to run lda model: ' + str(e))
            return API_FAILURE
        return results
'''
ip = "Yet for all its stylishness and period grandeur it is not as intelligent a film as it yearns to be, the plot isn't cunning enough and the conveniently-unravelled puzzle never quite sucks the viewer in :)"
#ip = "not really good"
#print "processing text " , ip
api_key = "46:3a:bf:30:42:03:5d:83:e1:21:28:32:f6:f0:38:39"
print wflow_manager("api").wf_get_sentiment_scores(api_key, ip)
#print wflow_manager().wf_validate_api_key("46:3a:bf:30:42:03:5d:83:e1:21:28:32:f6:f0:38:39")
'''

