import textacy
import spacy
import textacy.keyterms
from typing import List, Dict, Tuple, Optional, Any
from src.nlp.load_models import load_nlp_models

class extract_phrases(object):

    def __init__(self, spacy_model=None):
        self.nlp = load_nlp_models() if spacy_model is None else spacy_model
        return

    def get_phrases_sgrank(self,text: str) -> List[Tuple[str,float]]:
        phrases: List[Tuple[str,float]]
        
        text = text.lower()
        doc = self.nlp(text)
        phrases = textacy.keyterms.sgrank(doc, ngrams=(2, 4), normalize='lower', n_keyterms=10)
        
        return phrases
