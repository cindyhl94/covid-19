from src.common.fricles_logger import *
import tensorflow_hub as hub

import spacy

def singleton():
    def singleton_decorator(func):
        return _singleton_wrapper(func)

    return singleton_decorator


def _singleton_wrapper(func):
    value = None

    def wrapper(*args, **kwargs):
        nonlocal value

        if value is None:
            value = func(*args, **kwargs)

        return value

    return wrapper

@singleton()
def load_nlp_models():
    try:
        nlp = spacy.load("en_core_web_lg")
    except Exception as e:
        fricles_logger.debug("Failed to load spacy large model")
        raise
    return nlp

@singleton()
def load_coref_model():
    try:
        nlp = spacy.load('en_coref_lg')
    except Exception as e:
        fricles_logger.debug('Failed to load coref model: ' +str(e))
        raise
    return nlp

@singleton()
def load_sent2vec_model():
    from sent2vec import Sent2vecModel

    model_path = "/Users/cganjihal/repo/QBit/models/torontobooks_unigrams.bin"

    fricles_logger.info('Loading sent2vec model ' + model_path)
    model = Sent2vecModel()
    # This will exit the process if the model can't be loaded; no Exception to catch.
    try:
        model.load_model(model_path)
    except Exception as e:
        fricles_logger.debug(f'Failed to load sent2vec model')
    return model

@singleton()
def load_tf_universal_sent_encoder():
    model_path = "/Users/cganjihal/repo/QBit/models/use"
    embed = hub.Module(model_path)

    return embed
