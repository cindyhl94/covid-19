# -*- coding: utf-8 -*-
"""
Created on Wed Jun 22 11:35:21 2016

@author: pratibha
@author: supertramp
"""
from __future__ import print_function
import re

'''
Used as a decorator to remove unwanted periods to avoid incorrect sentence tokenizations.
Eg: 'EMC was No.2 in 2005 and No.3 in 2004.' will now be modified to
'EMC was No 2 in 2005 and No 3 in 2004.'
'''
def review_fullstops(process_text):
    def wrapper(*args, **kwargs):
        t1 = args[1]
        op = re.findall(r'[A-Za-z]+\.\s?\d+\s+',t1)
        if not op:
            return process_text(t1)
        else:
            #further changes: sub with space only if there is no space between the . and following character
            #No.2 == No 2 and No. 2 == No 2
            op1 = map(lambda x: re.sub(r'\.',' ',x), op)
            for i in range(0,len(op)):
                t1 = re.sub(op[i],op1[i],t1)

        return process_text(t1)
    return wrapper

def trim_symbol(statlist):
    statlist = [s.rstrip(',') for s in statlist]
    statlist = [s.rstrip('.') for s in statlist]
    return statlist


def remove_substring(statlist):
    # example: ["1950", "1950s", "million", "ten millions"] will provide ["1950s", "ten million"]
    #set to remove duplicates and converting back to list
    return list(set(i for i in statlist if not any(i in s for s in statlist if(i!=s))))

    
def cleanse(statlist):
    statlist = remove_substring(statlist)
    statlist = trim_symbol(statlist)
    return statlist


# Converting word numbers to digits
def is_int(string):
    try:
        int(string)
        return True
    except ValueError:
        return False

def is_float(string):
        try:
            float(string)
            return True
        except ValueError:
            return False

class dictionary:
    number = {'one':1, 'two':2, 'three':3,'four':4, 'five':5, 'six':6, 'seven':7, 'eight':8, 'nine':9, 'ten':10,
        'eleven':11, 'twelve':12, 'thirteen':13, 'fourteen':14, 'fifteen':15,'sixteen':16, 'seventeen':17,
            'eighteen':18, 'nineteen':19, 'twenty':20, 'thirty':30, 'forty':40, 'fifty':50, 'sixty':60, 'seventy':70,
                'eighty':80, 'ninety':90}
    place_value = {'hundred':100, 'thousand':1000, 'hundred thousand':100000, 'million':1000000, 'billion':1000000000, 'trillion':1000000000000,
        'lakh':100000, 'crore':10000000}
    def is_number(self, word):
        return self.number.has_key(word)
    def is_place_value(self, word):
        return self.place_value.has_key(word)
    def get_number(self, word):
        return self.number.get(word)
    def get_place_value(self, word):
        return self.place_value.get(word)

# Method to perform conversion of word numbers to digits
''' Cannot solve for the case, 
    3000 and 4 Vs 3004 ambiguity. This requires understanding the context whether the sentence mentions how many number values
    '''
def calc_place_value(currPlaceValue, prevPlaceValue):
    ''' # Cases like One hundred twenty three thousand four hundred and forty'''
    return (prevPlaceValue * currPlaceValue) if(currPlaceValue < prevPlaceValue) else currPlaceValue

def format_numbers_output(digit,second_digit, num_count):
    return str(digit)+" and "+str(second_digit) if (num_count == 2) else str(digit)


    
def words_to_numbers(phrase):
    #print("--------------Inside words_to_numbers function---------------", phrase)
    '''ASSUMPTIONs: 
    1. This assumes there are no preceding spaces are other non-word characters. The word number starts
    at FIRST_POS. 
    2. At the max a word number phrase can only hold two digits. A phrase like 'one and three and five and sixteen cannot
    be parsed into 1, 3, 5, 16''' 
    # converting all chars to lower case
    phrase = phrase.lower()
    # splitting the phrase into word list
    words = phrase.split(' ')

    # Parameters
    dt = dictionary()
    FIRST_POS = 0
    RESET_DIGIT = -1
    skip = False

    num_count = 1
    # The digit is reset to -1 instead of 0 to detect issue 24: '0' detected in highlights
    digit = RESET_DIGIT
    second_digit = 0
    place = 1


    # NOTE: ignores any word that are not in the list and continues parsing prior words. It is upto the
    # user to provide phrase containing only the relevant number word phrases as INPUT.
    for w in reversed(words):
        #print("Currnet word: ",w,"Current place value:", place, "current digit = ",digit)
        w_index = words.index(w)
        if(is_int(w)):
            # Cases like 9 million,
            if(digit == RESET_DIGIT):
                # First time initializing. 
                digit = 0
            digit = digit + (place * int(w))
        elif (dt.is_number(w)):
            # regular word number 1-20,30,40....90
            if(digit == RESET_DIGIT):
                digit = 0
            digit = digit + (place * dt.get_number(w))
        #place = 10
        elif (skip):
            # Skipping current place holder and resetting the value
            skip = False
        elif (dt.is_place_value(w)):
            curr_place = dt.get_place_value(w)
            place = calc_place_value(curr_place, place)

            #print("---------------------assgn----------", curr_place, place)
            # checking for cases like "hundred thousand"
            if(not w_index == FIRST_POS):
                prev_word = words[w_index-1]
                if(dt.is_place_value(prev_word)):
                    # override place value
                    place = dt.get_place_value(prev_word) * dt.get_place_value(w)
                    if((w_index - 1) == FIRST_POS):
                        # example hundred million years ago where the place value is not preceded by any word number
                        #print("--------------------SET place as digit-------------------")
                        digit = place
                    print("Setting Skip Flag")
                    skip = True
            else:
                # Cases like hundred and fifty = 150 where the place holder is the first word
                if(digit == RESET_DIGIT):
                    digit = 0
                digit = digit + place
            #print("Place_holder: ", w, "Value: ", place)
        elif (w == "and"):
            '''Checking if the phrase contains two numbers or one. E.g. forty five and forty six,
                six hundred and seventy and eight'''
            and_index = words.index(w)
            and_prev = words[and_index-1]
            and_next = words[and_index+1]
            if(dt.is_number(and_prev) and dt.is_number(and_next)):
                num_count = 2
                second_digit = digit
                # resetting all parameters for parsing the second digit
                digit = RESET_DIGIT
                place = 1
            
    #print("Returning these numbers. 1. = ", digit, " 2. = ", second_digit)
                

    return format_numbers_output(digit, second_digit, num_count)
