import spacy
from src.common.fricles_logger import *

class do_nlp(object):

    def __init__(self, text=None):
        self.nlp = spacy.load("en_core_web_lg")
        if text is not None:
            self.doc = self.nlp(text)
        return

    def get_entities(self, text=None, union=False, stem=True):
        """
        Use NER to get entities
        Args:
                text (str): text from which entities need to be extracted
                union (bool): merges(union) of all entities in a single list
        Returns:
                dict: list of entities for each entity type
                list: list of merged(union of) entities
        """
        fricles_logger.info('Extracting entities...started')
        entities = {}
        union_entities = []
        if text is not None:
            self.doc = self.nlp(text)

        for ent in self.doc.ents:
            if ent.label_ not in entities:
                entities[ent.label_] = []
            if ent.text not in entities[ent.label_]:
                entities[ent.label_].append(ent.text)
            if union and ent.text not in union_entities:
                union_entities.append(ent.text)

        fricles_logger.info('Extracting entities...done!')
        return entities, union_entities

    def get_noun_chunks(self, text=None):
        """
        Get noun chunks
        Args:
                text (str): text from which noun chunks need to be extracted
        Returns:
                dict: list of noun chunks
        """
        fricles_logger.info('Extracting noun chunks...started!')
        noun_chunks = []

        if text is not None:
            self.doc = self.nlp(text)

        for chunk in self.doc.noun_chunks:
            if chunk.text not in noun_chunks:
                noun_chunks.append(chunk.text)

        fricles_logger.info('Extracting noun chunks...done!')
        return noun_chunks

    def do_the_whole_thing(self, text=None):
        """
        Process text to extract entities, NCs and everything else of interest
        Args:
                text (str): text on which nlp ops need to be performed
        Returns:
                dict: list of nlp specific outputs
        """
        fricles_logger.info('Performing nlp ops...started!')
        output = {}
        #to comply with current UI's requirements of providing highlights
        output["entities"], output["highlights"]  = self.get_entities(text, union=True)
        output["noun_chunks"] = self.get_noun_chunks(text)
        fricles_logger.info('Performing nlp ops...done!')

        return output

    def get_ngrams(self, text=None):
        
        return 
        
    
