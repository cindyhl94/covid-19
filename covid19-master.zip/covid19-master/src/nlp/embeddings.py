import logging
from typing import Union, Iterable
import numpy as np

def embed_text(text, num_threads=2):
    model = load_model()

    return model.embed_sentence(text).reshape(1, -1)


