
from sklearn.metrics.pairwise import cosine_similarity
import textacy
import textacy.keyterms
from src.nlp.load_nlp_models import load_models

class document_similarity(object):

    def __init__(self):
        self.lm = load_models()
        self.sent2vec = self.lm.load_sent2vec_model()
        return

    def represent_document(self, text):
        
        doc = self.nlp(text)
        phrases = textacy.keyterms.sgrank(doc, ngrams=(2,6), normalize='lemma',n_keyterms=1000)

        return phrases


    def get_sent2vec_similarity(self, src, tgt):

        emb_src = self.sent2vec.embed_sentence(src.lower())
        emb_target = self.sent2vec.embed_sentence(tgt.lower())
        sim_score = cosine_similarity(emb_src.reshape(1,-1), emb_target.reshape(1,-1))

        return sim_score[0]


src = "Searching for volunteers to sew cloth face masks and scrub hats"
tgt = "sew masks and hats"
tgt1 = "pick up and drop of medicines"
ds = document_similarity()
score = ds.get_sent2vec_similarity(src, tgt)
print(score)
score = ds.get_sent2vec_similarity(src, tgt1)
print(score)
