"""
../.. module:: lda_models
   :synopsis: Implementaiton of building lda models using gensim and sklearn
../.. moduleauthor:: Supertramp
"""
import gensim
import gensim.corpora
from gensim.models.wrappers import LdaMallet
from gensim.models import CoherenceModel
from sklearn.feature_extraction.text import CountVectorizer, TfidfTransformer
from sklearn.decomposition import NMF
from sklearn.preprocessing import normalize

from typing import List, Dict, Optional, Tuple

from src.pre_process.clean_data import cleanse_data
from src.common.fricles_logger import *

NUM_TOPICS = 4
DEFAULT_WORKERS = 4
DEFAULT_PASSES = 10

class do_lda(object):
    def __init__(self, data=None):
        self.cd = cleanse_data()
        if data is not None:
            self.clean_data = self.cd.remove_stopwords(data)

        return

    def do_data_prep(self, data:List[str]) -> List:
            processed_docs = []
            for doc in data:
                processed_docs.append(self.cd.preprocess(doc))

            dictionary = gensim.corpora.Dictionary(processed_docs)
            #dictionary.filter_extremes(no_below=15, no_above=0.1, keep_n= 100000)
            bow_corpus = [dictionary.doc2bow(doc) for doc in processed_docs]

            return bow_corpus, dictionary

    def get_gensim_lda_topics(self, model: gensim.models.LdaMulticore, num_topics: int) -> Dict[str, List[str]]:
        '''
        Extract topics from the ldamodel
        Args:
                model (gensim.models.ldaodel): model output from gensim's topic model
                num_topics (int): number of topics
        Returns:
                word_dict (dict): dictionary with topic_id as key and topics as values
        '''
        word_dict: Dict[str,List[str]] = {}
        try:
            for i in range(num_topics):
                words = model.show_topic(i, topn = 20);
                word_dict['Topic # ' + '{:02d}'.format(i+1)] = [i[0] for i in words]

            return word_dict

        except Exception as e:
            fricles_logger.debug('Failed to extract topics from the model: ' + str(e))

            return None

    def do_multicore_lda(self, data: List[str], num_topics: Optional[int] = None) -> gensim.models.LdaMulticore:
        '''
        Train your lda model using gensim.models.LdaMulticore
        Args:
                data (list): input data for topic modeling
                num_topics (int): number of topics
        Returns:
                lda_model (gensim.models.LdaMulticore): lda model
        '''

        '''create corpus and id2word dictionary
        '''
        try:
            bow_corpus, dictionary = self.do_data_prep(data)

            lda_model =  gensim.models.LdaMulticore(bow_corpus,
                                                    num_topics=num_topics,
                                                    id2word=dictionary,
                                                    passes=10,
                                                    workers=DEFAULT_WORKERS)

            perplexity = lda_model.log_perplexity(bow_corpus)
            coherence_model_lda = CoherenceModel(model=lda_model, texts = data, \
                                                 dictionary = dictionary, coherence = "c_v")
            coherence_score = coherence_model_lda.get_coherence()
            fricles_logger.info('Perplexity...' + str(perplexity))
            fricles_logger.info('Coherence...' + str(coherence_score))

        except Exception as e:
            fricles_logger.debug('Failed to create lda model: ' + str(e))
            return None

        return lda_model

    def do_mallet_lda(self, data: List[str], num_topics: Optional[int] = None) -> LdaMallet:
        '''
        Train your lda model using gensim.models.LdaMulticore
        Args:
                data (list): input data for topic modeling
                num_topics (int): number of topics
        Returns:
                lda_model (gensim.models.LdaMulticore): lda model
        '''

        '''create corpus and id2word dictionary
        '''
        try:
            bow_corpus, dictionary = self.do_data_prep(data)
            mallet_path = 'data/mallet-2.0.8/bin/mallet'
            ldamallet = gensim.models.wrappers.LdaMallet(mallet_path, corpus=bow_corpus, num_topics=num_topics,
                                                         id2word = dictionary)
        except Exception as e:
            fricles_logger.debug('Failed to create lda model: ' + str(e))
            return None

        return ldamallet, dictionary, data

    def get_mallet_lda_topics(self, data: List[str], model: gensim.models.wrappers.LdaMallet,\
                              dictionary) -> Dict[str, List[str]]:
        '''Extract topics from ldamallet model
        Args:
                model (LdaMallet): model 
        Returns:
                word_dict (dict): dictionary of topic id and associated topics
        '''
        word_dict = {}
        try:
            coherence_model_ldamallet = CoherenceModel(model=model, texts=data, dictionary=dictionary,
                                                       coherence='c_v')
            coherence_ldamallet = coherence_model_ldamallet.get_coherence()
            fricles_logger.info('malletlda coherence score ...' + str(coherence_ldamallet))
            topics = coherence_model_ldamallet.top_topics_as_word_lists(model, dictionary)

            for topic_id in range(len(topics)):
                word_dict['Topic # ' + '{:02d}'.format(topic_id+1)] = topics[topic_id]
        except Exception as e:
            fricles_logger.debug('Failed to extract topics from ldamallet mdel...' + str(e))
            return None
        
        return word_dict

    def do_mallet_lda_get_topics(self, data: List[str], num_topics: Optional[int] = None) -> LdaMallet:
        '''
        Train your lda model using gensim.models.LdaMulticore
        Args:
                data (list): input data for topic modeling
                num_topics (int): number of topics
        Returns:
                lda_model (gensim.models.LdaMulticore): lda model
        '''
        try:
            ldamallet_dictionary = self.do_mallet_lda(data, num_topics)
            ldamallet = ldamallet_dictionary[0]
            dictionary = ldamallet_dictionary[1]
            data = ldamallet_dictionary[2]
            word_dict = self.get_mallet_lda_topics(data, ldamallet, dictionary)
        except Exception as e:
            fricles_logger.debug('Failed to create and get topics from ldamallet:' + str(e))
            return None
        
        return word_dict
   
    def do_multicore_lda_get_topics(self, data: List[str], num_topics: Optional[int] = None) -> Dict[str,List[str]]:
        '''Create LDA model
        Args:
                data (list): input data for topic modeling
                num_topics (int): number of topics
        Returns:
                op (dict): dictionary of topic_id and associated topics
        '''
        op = {}
        try:
            lda_model = self.do_multicore_lda(data, num_topics)
            op = self.get_gensim_lda_topics(lda_model, num_topics)
        except Exception as e:
            fricles_logger.debug('Failed to create ldamodel or extract topics: ' + str(e))
            return None

        return op


    def do_nmf_lda(self, data: List[str], num_topics: Optional[int] = None) -> Tuple[NMF, CountVectorizer]:
        '''Create LDA based on Non-negative matrix factorization (NMF)
        Args:
                data (list): input data to build the model
                num_topics (int): number of topics
        Returns:
                model (NMF),  vectorizer (CountVectorizer): model and vectorizer
        '''
        try:
            vectorizer = CountVectorizer(analyzer='word', max_features=5000)
            x_counts = vectorizer.fit_transform(data)
            transformer = TfidfTransformer(smooth_idf=False)
            x_tfidf = transformer.fit_transform(x_counts)
            xtfidf_norm = normalize(x_tfidf, norm='l2', axis=1)
            model = NMF(n_components=num_topics, init='nndsvd')
            model.fit(xtfidf_norm)
        except Exception as e:
            fricles_logger.debug('Failed to create nmf lda:' + str(e))
            return (None, None)

        return (model, vectorizer)

    def get_nmf_topics(self, model: NMF, vectorizer: CountVectorizer, num_topics: int, n_top_words: int) -> Dict[str,List[str]]:
        '''Get the topics and associated words
        Args:
                model (NMF): NMF lda model
                vectorizer (CountVectorizer): count vectorizer
                num_topics (int): number of topics
                n_top_words (int): numebr of words per topic
        '''
        #the word ids obtained need to be reverse-mapped to the words so we can print the topic names.
        try:
            feat_names = vectorizer.get_feature_names()
            word_dict = {}
            for i in range(num_topics):
                #for each topic, obtain the largest values, and add the words they map to into the dictionary.
                words_ids = model.components_[i].argsort()[:-20 - 1:-1]
                words = [feat_names[key] for key in words_ids]
                word_dict['Topic # ' + '{:02d}'.format(i+1)] = words;
        except Exception as e:
            fricles_logger.debug('Failed to extract topics from NMF model:' + str(e))
            return None

        return word_dict

    def do_nmf_lda_get_topics(self, data: List[str], \
                                num_topics: Optional[int] = None, \
                                clean_data: Optional[bool] = True) \
    -> Dict[str, List[str]]:
        '''Topic models based on NMF algorithm
        Args:
                data (list): input data-list of sentences/documents
                clean_data (bool): flag to indicate if data
                                        needs to be cleansed
                num_topics (int): number of topics, if present
                                        overrides auto ml feature
        Returns:
                op (dict): topic_id and associated topics
        '''
        op = {}
        processed_docs = []
        if clean_data:
            for doc in data:
                processed_docs.append(self.cd.preprocess(doc))
            pr_data = list(map(lambda x: " ".join(x), processed_docs))
        else:
            pr_data = data

        try:
            model_vectorizer = self.do_nmf_lda(pr_data, num_topics)
            model = model_vectorizer[0]
            vectorizer = model_vectorizer[1]

            if model is None and vectorizer is None:
                return None
            else:
                op = self.get_nmf_topics(model, vectorizer, num_topics, 20)
        except Exception as e:
            fricles_logger.debug('Failed to get a nmf model: ' + str(e))
            return None

        return op
