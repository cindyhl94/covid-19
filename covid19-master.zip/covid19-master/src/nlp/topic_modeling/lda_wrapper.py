from src.nlp.topic_modeling.lda_models import do_lda
from src.common.fricles_logger import *
from typing import List, Dict, Tuple, Optional

class wrap_lda_models(object):

    def __init__(self):
        self.lda = do_lda()
        return

    def do_mallet_lda(self, data: List[str], num_topics: Optional[int] = 6) -> Dict[str, List[str]]:
        '''
        '''
        op = self.lda.do_mallet_lda_get_topics(data=data, num_topics=num_topics)
        return op

    def do_gensim_lda(self, data: List[str], num_topics: Optional[int] = 6) -> Dict[str, List[str]]:
        '''
        '''
        op = self.lda.do_multicore_lda_get_topics(data=data, num_topics=num_topics)
        return op

    def do_nmf_lda(self, data: List[str], num_topics: Optional[int] = 6, clean_data: Optional[bool] = True) -> Dict[str, List[str]]:
        '''
        '''
        op = self.lda.do_nmf_lda_get_topics(data=data, num_topics=num_topics, clean_data = True)
        return op

    def run_all_lda_models(self, data: List[str], num_topics: Optional[int] = 6) -> Dict:
        '''
        Runs all the underlying lda models for topic modeling
        Args:
            data (list): input_data on which the lda models are run
            num_topics (int): number of topics/categories
        Returns:
            return_type (dict): results containing status message and topics
        '''
        try:
            fricles_logger.info('Starting Mallet Lda...')
            mallet_op = self.do_mallet_lda(data, num_topics)
            fricles_logger.info('Starting Gensim Multicore Lda...')
            gensim_lda_op = self.do_gensim_lda(data, num_topics)
            fricles_logger.info("Starting SKLearn's NMF Lda...")
            nmf_op = self.do_nmf_lda(data, num_topics, clean_data=True)

            fricles_logger.info('Aggregating resutls of the all the lda models...')
            return_type['status'] = 0
            return_type['status_string'] = "success"
            return_type['result'] = [mallet_op, gensim_lda_op, nmf_op]
        except Exception as e:
            fricles_logger.error('Failed to process topicmodeling workflow: ' + str(e))
            return API_FAILURE
        
        return return_type
