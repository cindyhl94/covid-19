import textacy

from src.common.fricles_logger import *
from src.nlp.load_models import load_nlp_models
from typing import List, Dict

NUM_TOPICS = 3

class do_textacy_lda_models(object):

    def __init__(self):
        #self.nlp = load_nlp_models()
        fricles_logger.info('textacy lda model... init')
        self.vectorizer = textacy.Vectorizer(tf_type = 'linear', apply_idf = True,
                                             idf_type = 'smooth', norm='l2', 
                                             min_df = 2, max_df = 5)
        return

    def do_lda(self, data: List[str]) -> textacy.TopicModel:
        '''
        Do topic modeling with default LDA settings using textacy
        Args:
                data (list): List of documents/text where each document is a string
        Returns:
                lda model (textacy.TopicModel): the model containing topics
        '''
        #create a corpus
        try:
            #docs = self.nlp.pipe(data)
            #corpus = textacy.Corpus('en', texts = data)
            fricles_logger.info('Creating corpus...')
            corpus = textacy.Corpus('en', texts = data)
        except Exception as e:
            fricles_logger.debug('Failed to create textacy corpus:' + str(e))
            return None

        try:
            doc_term_matrix = self.vectorizer.fit_transform(doc.to_terms_list(ngrams=1, 
                                                                         named_entities = True,
                                                                         as_strings = True)
                                                       for doc in corpus)
            fricles_logger.info(f'Creating lda model with {NUM_TOPICS}...')
            model = textacy.TopicModel('nmf', n_topics = NUM_TOPICS)
            model.fit(doc_term_matrix)
            doc_topic_matrix = model.transform(doc_term_matrix)
            return model
        except Exception as e:
            fricles_logger.debug('Failed to topic model using textacy: ' + str(e))
            return None

    def get_textacy_topics(self, model: textacy.TopicModel) -> Dict[str, str]:
        '''
        Extract topics from the ldamodel
        Args:
                model (textacy.TopicModel): model output from textacy's topic model
        Returns:
                word_dict (dict): dictionary with topic_id as key and topics as values
        '''
        fricles_logger.info('Extracting topics from lda model...')
        word_dict: Dict[str,List[str]] = {}
        try:
            for topic_idx, top_terms in model.top_topic_terms(self.vectorizer.id_to_term, top_n=20):
                word_dict['Topic # ' + '{:02d}'.format(topic_idx+1)] = " ".join(top_terms)

            return word_dict
        
        except Exception as e:
            fricles_logger.debug("Failed to extract topics from textacy's topic model: " +str(e))
            return None

        return None
            
                
            
            

    
