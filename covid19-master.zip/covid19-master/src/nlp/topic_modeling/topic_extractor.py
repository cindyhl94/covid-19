import nltk
import re
import nltk
from nltk.corpus import brown
import json
from src.pre_process.cleanup import *

class topic_extractor(object):
 
    def __init__(self):
        self.cl = cleanup_text()
        pass

    # Extract the main topics from the sentence
    def extract(self, text):
        tags=[]
        result=[]
        
        #cleanup text
        #remove urls and special characters
        text = self.cl.remove_url(text)
        text = self.cl.remove_stop_words(text)
        
        tags=nltk.pos_tag(nltk.word_tokenize(text))
        for word,tag in tags:
            #print word, " : " , tag
            if tag=="NN" or tag=="NNS" or tag=="JJ" or tag=="RB" or tag=="NNP":
                result.append(word)

        return result        


    def get_topics(self, text):

        try :
            results = self.extract(text)
            fricles_logger.debug('topics : ' + str(results))
        except Exception as e:
            fricles_logger.debug('Exception! : ' + str(e))

        topics_output = {
                    "status" : { "status_code" : 0,
                                 "status_string" : "success"
                                 },
                    "output" :  results
                    }
            
        return topics_output

    def get_keywords(self, text):

        try :
            results = self.extract(text)
            fricles_logger.debug('topics : ' + str(results))
        except Exception as e:
            fricles_logger.debug('Exception! : ' + str(e))
            
        topics_output = {
                    "status" : { "status_code" : 0,
                                 "status_string" : "success"
                                 },
                    "output" :  results
                    }
            
        return topics_output
 

       
 
text = """The 2019-nCoV epidemic has spread across China and 24 other countries 1-3 as of February 8, 2020 . The mass quarantine measure implemented in the epidemic's epicenter, Wuhan, Hubei Province, China, on January 23, 2020, has stopped the human migration between Wuhan and other places. However, according to the local authorities, over five million people had already traveled from Wuhan to other parts of China in the weeks leading to January 23, 2020, with the majority (79.96%) to the other cities within Hubei." }, { "text" : "Healthcare resources have become a major bottleneck in the response to this public health crisis. The sudden onset of the epidemic and the sheer size of the infection have caused significant shortage in healthcare resources across Hubei Province. So far, there have been over 11,000 non-local healthcare professionals, mobilized by the public health authorities from other parts of China, fighting against the epidemic in Wuhan. However, this is far from adequate for Wuhan given the severity of the epidemic. In addition to Wuhan, other cities in Hubei are in need of urgent external help as well with respect to health resources, as multiple localized outbreaks are taking place. On February 7, 2020, the National Health Commission of China (NHCC) initiated the \"One City Covered by One Province\" program, explicitly assigning a specific province to aid one city in Hubei. Two critical questions of operational nature remain, which cities, both in Hubei and other provinces, are most vulnerable to localized outbreaks, and how the public health authorities should balance the healthcare resources under stress to best fight the epidemic and minimize the risks? This study is aimed to shed light on these questions by developing a vulnerability analysis framework integrating the human movement and healthcare resource data""".strip()

text = "Due to the mobile phone GPS horizontal error and uncertainty, such physical distancing patterns cannot be directly identified from the used aggregated mobility data; it requires other wearable sensors or bluetooth trackers, which raise issues of personal data privacy and ethical concerns".strip()
print(topic_extractor().extract(text))
