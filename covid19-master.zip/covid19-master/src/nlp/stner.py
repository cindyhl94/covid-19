
# coding: utf-8

# In[1]:

import nltk
from nltk.tag import StanfordNERTagger
from nltk.tokenize import word_tokenize


# In[2]:

'''Configuring environment'''

import os
#setting classpath to point to stanford NER jar file
stanfordNERClasspath =  "/Users/pratibha/Documents/Preethi Work/stanford-ner-2015-12-09"
os.environ['CLASSPATH'] =  stanfordNERClasspath
os.environ.get('CLASSPATH')
#setting Java path
java_home = "/Library/Java/JavaVirtualMachines/jdk1.8.0_77.jdk/Contents/Home"
os.environ['JAVAHOME'] = java_home


# In[3]:

#--------------METHODS-----------------
def get_tags(tagged):
    tags = dict()
    for x,y in tagged:
        if(tags.has_key(y)):
            tags[y].append(x)
        else:
            tags[y] = [x]
    return tags


# In[4]:

#3 class classifier. 
def ner3ClassClassifier(text):
    st = StanfordNERTagger('/Users/pratibha/Documents/Preethi Work/stanford-ner-2015-12-09/classifiers/english.all.3class.distsim.crf.ser.gz',
                       '/Users/pratibha/Documents/Preethi Work/stanford-ner-2015-12-09/stanford-ner.jar',encoding='utf-8')
    tokenized = word_tokenize(text)
    tagged = st.tag(tokenized)
    tags = get_tags(tagged)
    #print tags
    return tags
    


# In[5]:

#4 - class clssifier
def ner4ClassClassifier(text):
    st = StanfordNERTagger('/Users/pratibha/Documents/Preethi Work/stanford-ner-2015-12-09/classifiers/english.conll.4class.distsim.crf.ser.gz',
                      '/Users/pratibha/Documents/Preethi Work/stanford-ner-2015-12-09/stanford-ner.jar',encoding='utf-8')
    tokenized = word_tokenize(text)
    tagged = st.tag(tokenized)
    tags = get_tags(tagged)
    return tags


# In[6]:

#7 - class classifier
def ner7ClassClassifier(text):
    st = StanfordNERTagger('/Users/pratibha/Documents/Preethi Work/stanford-ner-2015-12-09/classifiers/english.muc.7class.distsim.crf.ser.gz',
                      '/Users/pratibha/Documents/Preethi Work/stanford-ner-2015-12-09/stanford-ner.jar',encoding='utf-8')
    tokenized = word_tokenize(text)
    tagged = st.tag(tokenized)
    tags = get_tags(tagged)
    return tags


# In[7]:

#st.tag('Rami Eid is studying at Stony Brook University in NY'.split()) 
#3 class classifier
#print tagged
#print type(tagged[2])
#print dict((y,x) for x,y in tagged)

