#!/usr/bin/python
# -*- coding: utf-8 -*- 
import math
import nltk
import numpy
import json, sys
import time
from collections import Counter
import chardet
import re

N = 100
CLUSTER_THRESHOLD = 5
TOP_SENTENCES = 3
NUM_INPUT_SENT = 0
SUMMARY_LENGTH = 10

#nltk.data.path.append("data/nltk_data")

def _score_sentences(sentences, important_words):
    scores = []
    sentence_idx = -1
    for s in [nltk.tokenize.word_tokenize(s) for s in sentences]:
        sentence_idx += 1
        word_idx = []
        for w in important_words:
            try:
                word_idx.append(s.index(w))
            except ValueError as e:
                pass
            
        word_idx.sort()
        if(len(word_idx)==0): continue
        clusters = []
        cluster = [word_idx[0]]
        i = 1
        while i < len(word_idx):
            if word_idx[i] - word_idx[i-1] < CLUSTER_THRESHOLD:
                cluster.append(word_idx[i])
            else:
                clusters.append(cluster[:])
                cluster = [word_idx[i]]
            i += 1
        clusters.append(cluster)
        #score each cluster
        max_cluster_score = 0
        for c in clusters:
            significant_words_in_cluster = len(c)
            total_words_in_cluster = c[-1] - c[0] + 1
            #print "significant words in cluster " , significant_words_in_cluster
            #print "total words in cluster ", total_words_in_cluster
            score = 1.0 * significant_words_in_cluster \
                * significant_words_in_cluster / total_words_in_cluster
            
            if score > max_cluster_score:
                max_cluster_score = score
                
        #print "appending score ", sentence_idx , " score ", score
        scores.append((sentence_idx, max_cluster_score))

    return scores

def summarize(txt):
    global NUM_INPUT_SENT

    sentences = [s for s in nltk.tokenize.sent_tokenize(txt)]
    NUM_INPUT_SENT = len(sentences)
    TOP_SENTENCES = int(math.ceil(0.3 * len(sentences)))
    normalized_sentences = [ s.lower() for s in sentences]

    words = [w.lower() for sentence in normalized_sentences for w in 
             nltk.tokenize.word_tokenize(sentence)]

    fdist = nltk.FreqDist(words)

    top_n_words = [w[0] for w in fdist.items()
                   if w[0] not in nltk.corpus.stopwords.words('english')][:N]


    scored_sentences = _score_sentences(normalized_sentences, top_n_words)
    #print "Scored sentences " , scored_sentences

    #approach 1
    avg = numpy.mean([s[1] for s in scored_sentences])
    std = numpy.std([s[1] for s in scored_sentences])
    mean_scored = [(sent_idx, score) for (sent_idx, score) in scored_sentences
                   if score > avg + 0.5 * std]

    #approach 2
    top_n_scored = sorted(scored_sentences, key=lambda s: s[1])[-TOP_SENTENCES:]
    top_n_scored = sorted(top_n_scored, key=lambda s: s[0])
    
    #save the summary
    return dict(top_n_summary = [sentences[idx] for (idx, score) in top_n_scored],
                mean_scored_summary=[sentences[idx] for (idx, score) in mean_scored])
    

def gen_summary(txt):
    op = summarize(txt)
    result = op['mean_scored_summary'][:SUMMARY_LENGTH]
    text = " ".join(result)
    t1 = re.sub(r'[\n]+','',text)
    return t1
    
def valid_xml_char_ordinal(c):
    codepoint = ord(c)
    # conditions ordered by presumed frequency
    return (
        0x20 <= codepoint <= 0xD7FF or
        codepoint in (0x9, 0xA, 0xD) or
        0xE000 <= codepoint <= 0xFFFD or
        0x10000 <= codepoint <= 0x10FFFF
        )    
