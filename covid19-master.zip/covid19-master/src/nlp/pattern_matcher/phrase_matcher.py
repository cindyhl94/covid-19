
import spacy
from spacy.matcher import PhraseMatcher
from src.common.patterns import ethics

nlp = spacy.load('en_core_web_sm')
matcher = PhraseMatcher(nlp.vocab)

terms = ethics.misinformation

patterns = [nlp.make_doc(text) for text in terms]

matcher.add("EthicsTerms", None, *patterns)

def find_matches(messages):

    docs = nlp.pipe(messages, n_threads=8, batch_size=1000)
    for doc in docs:
        op, _ = phrase_match(doc)
    return op


def phrase_match(doc):
    
    matches = matcher(doc)
    ret_type = False
    if matches:
        for match_id, start, end in matches:
            span = doc[start:end]
            
            return True, span
    return ret_type, ""

