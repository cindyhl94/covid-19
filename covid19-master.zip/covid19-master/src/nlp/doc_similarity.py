from sklearn.feature_extraction.text import TfidfVectorizer
#from news_wflow import *

class doc_similar(object):
    
    def __init__(self):
        self.tfidf = None
        self.vect = TfidfVectorizer(min_df=1)
        #self.wf = news_wflow_manager(db_name="content",coll="articles")
        pass

    def get_tfidf_matrix(self,doc_lists):
        self.tfidf = self.vect.fit_transform(doc_lists)
        op = (self.tfidf*self.tfidf.T).A
        return op
    
    def check_doc_similarity(self,docs):
        #get more docs(titles)from db
        #docs = self.wf.get_all_titles()
        #docs.append(doc)
        op = self.get_tfidf_matrix(docs)
        print(op)
        op = op[len(op)-1,]
        o = filter(lambda x: x>0.3, op[:len(op)-1])
        return True if 0 else False
        


#print ds.check_doc_similarity("hello")
docs = [
    "Home pickup and delivery for laundry in Inner West Sydney - based in Annandale",
    "Happy to grab groceries, animal food, medications  etc. for seniors/disabled/carers.",
    "Fencing supplies are needed for property owners with small but necessary fencing replacement jobs that will be low on any funding or labour group's priority lists.  These people own animals that they raise to supplement their regular incomes or for food for their immediate and extended families.  Without assistance to replace burned fences, these property owners will have to destock, meaning their long term situations will be impacted.",
    "I‚ am in the northwest of Sydney and happy to shop for people and deliver groceries or do fill a script at chemist. Also happy to write letters to anyone feeling lonely with the self isolation.",
    "Hello, I live in Manly and would love to provide support to anyone in the area needing help with groceries or other errands, or to phone people who might feel a bit isolated." 
]
    
ds = doc_similar()
print(ds.check_doc_similarity(docs))
      
