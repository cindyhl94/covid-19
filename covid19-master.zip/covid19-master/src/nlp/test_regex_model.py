#!/usr/bin/python
# coding: utf-8
import re
from regex import *

class test_regexModel(object):
    
    def __init__(self):
        self.reg = extract_highlights()
        pass

    def get_number(self):
        text = '''999 The change Boston will see gives a good example of how much milder it
        will become as Olympia moves through the Northeast. After dipping to a low of minus 9 degrees Sunday morning,
        Boston will be in the middle 50s with rain on Tuesday.'''
        return  self.reg.getNumber(text)

    def get_word_number(self):
        text = '''I need to find a string that contains one number and two string characters between A-M'''
        return self.reg.getWordNumber(text)

    def get_illion_words(self):
        text = '''Musk later led Tesla Motors' Series B, US$13 million, investment round that added Valor Equity 
                Partners to the funding team. Musk co-led the third, US$40 million round in May 2006 along with Technology Partners. 
                Random text can also contain words like 350 Billion dollars and 487689 Trillion years away'''
        return self.reg.getIllions(text)

    def get_percent_symbol(self):
        percentText = '''In addition, FIH Mobile (a subsidiary of Hon Hai) became the largest shareholder of migme Limited, 
            a social entertainment platform, through a $9.6 million investment that gave the Foxconn-linked handset company 
            a 19.9% stake in the company.'''
        
        print self.reg.getPercentage(percentText)

    def get_measurements(self):
        metricText = '''Most tornadoes have wind speeds less than 110 miles per hour (180 km/h), are about 250 feet 
                (80 m) across, and travel a few miles (several kilometers) before dissipating. The most extreme 
                tornadoes can attain wind speeds of more than 300 miles per hour (480 km/h), stretch 
                more than two miles (3 km) across, and stay on the ground for dozens of miles (more than 100 km)'''
        return self.reg.getMeasurements(metricText)

    def get_currency_text(self):
        currencyText = '''I have a seed money of USD 30,000 which I have saved over the years. I left my job and now I am 
                staying with my parents to prepare for a few competitive exams. At best I can add about INR 3000 
                per month by saving on my pocket money or by doing odd jobs for friends or relatives.'''
        op = []
        op.extend(self.reg.getCurrency(currencyText))

        currencyText2 = '''I need 40,000 INR to complete the transaction.'''
        op.extend(self.reg.getCurrency(currencyText))

        return op
        
    def get_currency_symbol(self):
        text = '''Indirect participation in the form of retirement accounts rose from 39.3% in 1992 to 
                        52.6% in 2007 with the median value of these accounts more than doubling from $22,000 
                        to $45,000.98 in that time.'''
        return self.reg.getSymbolCurrency(text)


    def get_time(self):
        timeTextampm = ''' Our day officially starts at 9.30 am but some children arrive at 9.00 am itself.'''

        timeText = '''A major earthquake occurred in Nepal on 12 May 2015 at 12:50 pm local time (07:05 UTC) with 
            a moment magnitude of 7.3, 18 km (11 mi) southeast of Kodari.'''
        timeText2 = '''The Japan Aerospace Exploration Agency will launch a new X-ray space observatory called Astro-H  
                on Friday at 3:45 a.m. EST (5:45 p.m. local time) from the Tanegashima Space Center and you can watch 
                the launch live in the window below, courtesy of NASA. '''

        op = []
        #-------------------am/pm format = 9 am--------------------
        #NOTE: in some text like blogs the format can be jsut 9am without the space. we can include this too. 
        text = timeTextampm
        print "Does this text has time information in the am/pm format? - "+str(self.reg.hasTime(text))
        op.extend(self.reg.getTime(text))

        #-----------------time format = 23:00 -----------------------
        text = timeText 
        print "Does this text has time information in 00:00 format? - "+str(self.reg.hasTime(text))
        op.extend(self.reg.getTime(text))
        #------------------time casual format = "Come 5 minutes early....", "...time is 5 seconds..."
        return op

    def get_casual_time(self):
        op = []
        timeCasualText = '''The YMCA has a late fee policy that is $5 for the first 10 minutes and $1 for every minute after. 
                    The processing time for application is 3-5 days .'''
        timeCasualText2 = '''A 24-hour clock displays the time as the hours passed since midnight. So, 23:00 hours on a 
                    24-hour clock on February 15, means 23 hours have passed since midnight of February 15.'''
        timeCasualText3 = '''The current men's world record is 9.58 seconds, set by Jamaica's Usain Bolt in 2009, while 
                    the women's world record of 10.49 seconds set by American Florence Griffith-Joyner in 
                    1988 remains unbroken.'''

        text = timeCasualText
        op.extend(self.reg.getCasualTime(text))
        text = timeCasualText2
        op.extend(self.reg.getCasualTime(text))
        text = timeCasualText3
        op.extend(self.reg.getCasualTime(text))
        
        return op

    def get_timestamp(self):
        text = ''' the range for DATETIME values is '1000-01-01 00:00:00.000000' to '9999-12-31 23:59:59.999999',
                    and the range for TIMESTAMP values is '1970-01-01 00:00:01.000000' to 
                    '2038-01-19 03:14:07.999999'.'''
        
        return self.reg.getTimeStamp(text)

    def get_date(self):
        #------------------Date format = 12-12-2012 or 12/12/2012 or 1/12/2012 or 1/1/2010 or 1/2/98----------------
        #NOTE: this will also accept 01/01/012 as valid date. which need to be changed to either 2 or 4
        dateTextDot = '''The traditional all-numeric form of writing Gregorian dates in German is the little-endian 
                day.month.year order, using a dot on the line (period or full stop) as the separator
                (e.g., ��31.12.1991�� or ��15.4.74��).'''

        text = dateTextDot        
        return self.reg.getDate(text)

    def get_month(self):
        #-----------------month format = January or Jan---------------
        monthText = '''In October 2009, the company abandoned the Guardian America homepage, instead directing users to a 
                US news index page on the main website'''
        monthText2 = ''' The Republican Convention will take place from July 18 to July 21, 2016. The Democratic Convention
            will take place from July 25 to July 28, 2016.'''
        monthText3 = '''The series of presidential primary elections and caucuses is taking place between February 1 and 
            June 14, 2016, staggered among the 50 states, the District of Columbia and U.S. territories. '''
        monthText4 = '''Speculation about the 2016 campaign began almost immediately following the 2012 campaign, 
            with New York magazine declaring the race had begun in an article published on Nov 8, 2012, two days 
            after the 2012 election.'''

        text = monthText

        #print "Does this text contain month information in full or short form? - "+str(regex.hasMonth(text))
        op = []
        op.extend(self.reg.getMonth(text))
        op.extend(self.reg.getMonth(monthText2))
        op.extend(self.reg.getMonth(monthText3))
        op.extend(self.reg.getMonth(monthText4))

        return op

    def get_year(self):
        yearText = '''All the aforementioned were owned by The Scott Trust, a charitable foundation existing between 1936 
            and 2008, which aimed to ensure the paper's editorial independence in perpetuity, maintaining its 
            financial health to ensure it did not become vulnerable to take overs by for-profit media groups.'''
        return self.reg.getYear(yearText)

    def get_ADBC_year(self):
        text = '''For instance both Han Wudi and Jin Kangdi picked Jianyuan as their motto. Thus 344 AD was the
                        second year of Jianyuan of the Jin Dynasty (or of Jin Kangdi) whereas 139 BC was the second 
                    year of Jianyuan of the Han Dynasty (or of Han Wudi).'''
        return self.reg.getADBCYear(text)

    def get_trigram_outputs(self):
        text = "  \n\nIn June 2015, Telstra announced that \"more than fifty one % of all service transactions were done digitally and 34% was done in 50 million and forty trillion\". "
        
        return self.reg.get_trigram_outputs(text)

stat_model = test_regexModel()
print stat_model.get_number()
print stat_model.get_word_number()
print stat_model.get_illion_words()
print stat_model.get_percent_symbol()
print stat_model.get_measurements()
print stat_model.get_currency_text()
print stat_model.get_currency_symbol()
print stat_model.get_time()
print stat_model.get_casual_time()
print stat_model.get_timestamp()
print stat_model.get_date()
print stat_model.get_month()
print stat_model.get_year()
print stat_model.get_ADBC_year()
print stat_model.get_trigram_outputs()
