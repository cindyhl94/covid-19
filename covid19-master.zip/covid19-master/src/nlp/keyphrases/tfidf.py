from sklearn.feature_extraction.text import TfidfVectorizer
import numpy as np

def get_tfidf_scores(text):

    text = text.strip().lower()
    corpus = text.split('.')
    tf = TfidfVectorizer(analyzer='word', ngram_range=(2,3),
                         min_df = 1, stop_words = 'english', sublinear_tf=True)
    results = []
    try:
        tfidf_matrix =  tf.fit_transform(corpus)

        feature_names = tf.get_feature_names()
        results = []
        tfidf_op = []
        for doc in range(0,len(corpus)):
            feature_index = tfidf_matrix[doc,:].nonzero()[1]
            tfidf_scores = zip(feature_index, [tfidf_matrix[doc, x] for x in feature_index])
            scores = [(feature_names[i], s) for (i, s) in tfidf_scores]
            tfidf_op.extend(scores)
    except Exception as e:
        logger.debug(f"Failed to rank phrases based on TF-IDF: " + str(e))

    results = sorted(tfidf_op, key=lambda x: x[1], reverse=True)
    results = list(map(lambda x: x[0], results))
    tmp = []
    tmp_lst = []
    for res in results:
        if res[0] not in tmp:
            tmp.append(res[0])
            tmp_lst.append(res)

    results = tmp_lst

    return results


