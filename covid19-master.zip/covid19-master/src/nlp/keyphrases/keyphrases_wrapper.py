
from src.nlp.keyphrases.get_keyphrases import get_key_phrases
from src.common.fricles_logger import *
from typing import Dict, List, Optional, Tuple

class keyphrase_wrapper(object):

    def __init__(self):
        self.kp = get_key_phrases()
        return

    def run_all_kp_models(self, text: str) -> Dict:
        '''
        '''
        op = self.kp.get_keyphrases_sgrank(text)
        if op is None:
            return_type['status'] = -1
            return_type['status_string'] = "failed to extaract key phrases"
        else:
            return_type['status'] = 0
            return_type['status_string'] = "success"
            return_type['result'] = op

        return return_type
    

        
