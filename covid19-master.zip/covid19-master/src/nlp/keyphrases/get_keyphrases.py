
import textacy
import textacy.keyterms
import spacy
from src.nlp.load_models import load_nlp_models as load_spacy_model
from typing import Optional, Tuple, Dict, List
from src.common.fricles_logger import *

class get_key_phrases(object):

    def __init__(self):
        self.nlp = load_spacy_model()
        return

    def get_keyphrases_sgrank(self, text:str, scores: Optional[bool] = False) -> List[str]:
        '''Extracts sgrank based keyphrases usign textacy
        Args:
            text (str): input text
            scores (bool): optional flag to indicate if scores need to be part of output
        Returns:
            op (list): list of keyphrases
        '''
        op = []
        try:
            doc = self.nlp(text)
            op = textacy.keyterms.sgrank(doc, ngrams=(1, 2, 3, 4), normalize='lower', n_keyterms=0.2)
        except Exception as e:
            fricles_logger.error('Failed to extract keyphrases using textacy...:' + str(e))
            return None
        if not scores:
            op = list(map(lambda x: x[0], op))
        return op

