from src.common.fricles_logger import *
from src.nlp.load_models import load_coref_model

class do_coref(object):

    def __init__(self):
        fricles_logger.info("Initializing coref models ...")
        try:
            self.nlp = load_coref_model()
        except Exception as e:
            fricles_logger.debug('Failed to load en_coref_lg model: ' +str(e))
            return None
        return

    def resolve_corefs(self,text):
        """
        Resolves coref using huggingface: https://github.com/huggingface/neuralcoref
        Args:
                text (str): input text for which corefs are resolved
        Returns str: text with corefs resolved
        """
        doc = ""
        try:
            doc = self.nlp(text)
        except Exception as e:
            fricles_logger.debug("Failed to resolve corefs! "+ str(e))

        if doc._.has_coref:
            text = doc._.coref_resolved
            fricles_logger.info("Corefs detected...")
            print("After corefs ", doc._.coref_clusters)

        return text




