import nltk
from nltk.util import ngrams
from nltk import ne_chunk, pos_tag, word_tokenize
from nltk.tree import Tree
from nltk.corpus import wordnet

class do_nlp_stuff(object):

    def __init__(self):
        self.pos_whitelist = ['NN','NNS','VB','JJ','JJR','JJS','NNP','NNPS','RB','RBR','RBS','VBD','VBG','VBN','VBP','VBZ']
        self.pos_blacklist = ['DT','PRP$','VBZ']
        return

    def do_lemmatize(self,doc):
        tmp = map(lambda x: wordnet.morphy(x), doc.split())
        return " ".join(filter(lambda x: x != None,tmp))
        
    def rem_pos_neg_tags(self,doc):
        op = nltk.pos_tag(nltk.word_tokenize(doc))
        op = filter(lambda x: x[1] not in self.pos_blacklist, op)
        op = map(lambda x: x[0], op)
        return " ".join(op)
        
    def rem_pos_tags(self,doc):
        op = nltk.pos_tag(nltk.word_tokenize(doc))
        op = filter(lambda x: x[1] in self.pos_whitelist, op)
        op = map(lambda x: x[0], op)
        return " ".join(op)

    def get_tokens(self,doc,n=2,ngrams=None):
        tokens = None
        try:
            tokens =nltk.word_tokenize(doc)
        except Exception as e:
            print("Failed to tokenize: " + str(e))

        if ngrams is not None:
            return str(list(ngrams(tokens,n)))
        return tokens
 
    def get_ngrams(self,doc,n=2):
        tokens = None
        try:
            tokens = nltk.word_tokenize(doc)
        except Exception as e:
            print("Failed to tokenize: " + str(e))

        return str(list(ngrams(tokens,n)))

 
    def get_ner(self,doc):
        chunked = ne_chunk(pos_tag(word_tokenize(doc)))
        prev = None
        continuous_chunk = []
        current_chunk = []
        
        for i in chunked:
            if type(i) == Tree:
                current_chunk.append(" ".join([token for token, pos in i.leaves()]))
            elif current_chunk:
                named_entity = " ".join(current_chunk)
                if named_entity not in continuous_chunk:
                    continuous_chunk.append(named_entity)
                    current_chunk = []
            else:
                continue
                
        return continuous_chunk


nlp = do_nlp_stuff()
txt = "Barack Obama is a great person. (IOS) Executive Assistant Hong Kong and London. "
txt = "Malaysians share how they save money on coffee"
txt = """As we go through the solution keep in mind that we’ll try to make very few assumptions about Pong because we secretly don’t really care about Pong; We care about complex, high-dimensional problems like robot manipulation, assembly and navigation. Pong is just a fun toy test case, something we play with while we figure out how to write very general AI systems that can one day do arbitrary useful tasks.

Policy network. First, we’re going to define a policy network that implements our player (or “agent”). This network will take the state of the game and decide what we should do (move UP or DOWN). As our favorite simple block of compute we’ll use a 2-layer neural network that takes the raw image pixels (100,800 numbers total (210*160*3)), and produces a single number indicating the probability of going UP. Note that it is standard to use a stochastic policy, meaning that we only produce a probability of moving UP. Every iteration we will sample from this distribution (i.e. toss a biased coin) to get the actual move. The reason for this will become more clear once we talk about training.""".strip()

import wikipedia
txt = wikipedia.page('Climate change').content
print(nlp.get_ner(txt))

