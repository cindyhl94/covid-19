
#Patterns to detect accommodation related queries


pattern_details1 = {
    "LABEL" : "ACCOMMODATE",
    "pattern" : [
        { "TEXT" : { "REGEX" : "accommodat*" } }
    ]
}

pattern_details2 = {
    "LABEL" : "ACC_LEMMAS",
    "pattern" : [
        {"LEMMA": {"IN": ["give", "provide", "offer"]}},
        { "OP" : "*" },
        { "TEXT"  : { "REGEX" :  "accommodation" } }
    ]
}

pattern_details3 = {
    "LABEL" : "ACC_REGEX",
    "pattern" : [
        { "TEXT"  : { "REGEX" :  "accommodation|\bassistance\b|\bhous*\b|\bhotel\b|\bmotel\b|\bstay\b|\bhome\b|\bresiden\b*|\blodg\b*|\bhost\b|\binn\b|\bboarding\b|\bsuite\b|\bbunk\b|\brenter\b|\bbungalow\b" } },
    ]
}

fear_anxiety = {

    "LABEL" : "FA_REGEX",
    "pattern" : [
        { "TEXT" : { "REGEX" : "anxiety"
        }
        }
        ]
    }

patterns = [
    fear_anxiety
]

fear_anxiety_terms = ['anxiety','anger', 'arboviral', 'fear', 'political', 'accountability', 'radiomics', 'economic', 'enforcement', 'conditioning', 'infodemic', 'microblog', 'wellbeing', 'perceived', 'hunger', 'depressive', 'societal', 'underreporting', 'psychological', 'emotional', 'socio economical', 'mental', 'shutdowns', 'panic', 'loneliness', 'tragic', 'lifestyle', 'humanitarian', 'stress', 'devastation', 'posttraumatic', 'depression', 'stigma', 'xenophobia', 'rumour', 'hysteria', 'paranoia', 'social media', 'behavioural science', 'twitter', 'facebook', 'youtube', 'wechat', 'weibo', 'qzone', 'tiktok', 'douyin', 'instagram', 'linkedin', 'social-media', 'socialmedia', 'afraid', 'nervous', 'anxious']

op_section_file = "fa_matches.json"

misinformation = [ "misinformation", "disseminating disturbing and harmful information", "hate speech", "targeting chinese people", "sinophobia", "malicious content", "fake news", "fake information", "fake health information", "misleading information", "false news", "rumour", "rumor", "lack of evidence based"]

op_section_dir = "ethics_rumour_files"
