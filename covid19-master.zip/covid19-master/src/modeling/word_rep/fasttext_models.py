import fasttext
from configs import config as cfg

class build_fasttext_model(object):

    def __init__(self):
        return

    def train_unsup(self, filename:str, save_model = True) -> fasttext:

        model = fasttext.train_unsupervised(filename)
        print(model.words[:10])

        if save_model:
            model.save_model(cfg.model_save_path + filename + ".bin")
        return model
    

ft = build_fasttext_model()
ft.train_unsup("biorxiv_medrxiv_content_folded.txt")
