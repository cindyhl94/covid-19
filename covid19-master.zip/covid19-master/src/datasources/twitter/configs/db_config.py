MONGOCLIENT_HOST = "localhost"
MONGOCLIENT_PORT = 27017

DEFAULT_DB = "twitter"
DEFAULT_COLL = "tweets"

coll = "ethics"
uri = "mongodb://localhost:27017/"
db_name = "covid19"
