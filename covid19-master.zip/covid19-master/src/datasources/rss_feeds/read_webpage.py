
import re
from bs4 import BeautifulSoup
from src.common.fricles_logger import *
import urllib3
urllib3.disable_warnings()

class read_webpage_contents(object):

    def __init__(self,url=None):
        self.tags_of_interest = ['h1','h2','h3']
        return

    def read_url(self,url=None):
        if url is not None:
            try:
                #content = URL(url).download()
                #self.content = plaintext(str(content))
                return None#content
            except Exception as e:
                fricles_logger.debug("Failed to download url contents" + str(e))
                return None
        else:
            return None

    def rem_html_tags(self,txt):
        return re.sub(r'<.*?>',"",str(txt))


    def extract_content_from_tags(self, soup, tag):
        
        elements = soup.find_all(tag)
        items = list(map(lambda x: self.rem_html_tags(x), elements))
        items1 = list(filter(lambda x: not re.search(r"\.{5,}",x.strip()), items))
        return " ".join(items1)
    
    def get_images(self,soup):
        image_links = []
        image_tags = soup.findAll('img')
        for image_tag in image_tags:
            image_links.append(image_tag.get('src'))
            #@todo: filter images relavant to the article
            
        return image_links

    def read_html(self, url):
        http = urllib3.PoolManager()

        r = http.request('GET', url)
        if r.status != 200:
            print("Failed to fetch html content")
            return None
        
        soup = BeautifulSoup(r.data, 'html.parser')
        title = self.rem_html_tags(soup.title())

        headings = []

        for tag in self.tags_of_interest:
            head = self.extract_content_from_tags(soup, tag)
            head = head.encode('ascii','ignore').decode('ascii')
            headings.append(head)

        body = self.extract_content_from_tags(soup, 'p')
        body = body.encode('ascii','ignore').decode('ascii')
        #print("headings = " , headings)
        #print("body = ", body)
        content = " ".join(headings) + body
            
        return content
        
        

