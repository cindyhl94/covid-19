#!/usr/bin/python

import sys
import feedparser
import pprint
from calendar import *
import datetime
import time
import json
import re
from pymongo import MongoClient

from src.datasources.rss_feeds.read_webpage import *
from src.datasources.rss_feeds import config
from src.nlp import phrase_matcher as pm
from src.common.patterns import ethics

class get_rss_feeds(object):
    def __init__(self,feed_urls=None):
        self.rss_feed_urls = feed_urls
        self.rd = read_webpage_contents()

        self.db_client = MongoClient(port=27017)
        self.db = self.db_client[config.rss_feeds_db]

        return

    def write2db(self,obj):
        self.db[config.rss_feeds_db].insert_one(obj, config.rss_feeds_coll)
                
    '''if we need to call a url directly and not through rssfeeds
    '''
    def get_webpage(self, url):
        content = None
        content = self.rd.read_html(url)
        news_details = {}
        news_details['content'] = content
        news_details['url'] = url
        news_details['timestamp'] = datetime.datetime.now().timestamp()
        
        if config.apply_filters:
            if re.search(config.search_terms, content):
                if pm.find_matches([content.lower()]):
                    news_details['match_found'] = "ethics"
                self.write2db(news_details)
                return (news_details)
                
        return None
        
    # Retrieve a single page and report the url and contents
    def load_url(self,url, timeout=None):
        '''
        extract content here if we dont have duplicate content
        already stored in the db. dup content detection using
        doc similarity
        '''
        print("processing url", url['link'])
        content = None
        content = self.rd.read_html(url['link'])
        if content is None:
            return None
        news_details = {}
        news_details = url
        news_details['content'] = content
        news_details['url'] = url['link']
        if 'published_parsed' in url.keys():
            news_details['timestamp'] = timegm(url['published_parsed'])
            del news_details['published_parsed']

        if config.apply_filters:
            if re.search(config.search_terms, content):
                if pm.find_matches(content.lower()):
                    print("rss feed match found")
                    news_details['match_found'] = "ethics"
                self.write2db(news_details)
                return (news_details)
                
        return None

    def get_feed_content(self, feed_urls=None):
        flag = True
        while flag:
            for feed_url in self.rss_feed_urls:
                print("processing ", feed_url)
                self.process_1_feed(feed_url)
            time.sleep(1800)
            
    def process_1_feed(self,feed_url):
        '''
        To test without concurrent.futures, you could use this
        '''
        feed_op = feedparser.parse(feed_url)       
        parsed_content = []
        for entry in feed_op['entries']:
            op = self.load_url(entry)
            if op is None:
                continue

        return
                    

