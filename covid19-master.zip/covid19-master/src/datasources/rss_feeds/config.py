
rss_feeds_db = "rss_feeds"
rss_feeds_coll = "news"

apply_filters = True
search_terms = r"coronavirus|covid19|corona virus"

feed_urls = [
    "https://www.smh.com.au/rssheadlines",
    "http://rss.cnn.com/rss/edition.rss",
    "http://rss.cnn.com/rss/edition_africa.rss",
    "http://rss.cnn.com/rss/edition_americas.rss",
    "http://rss.cnn.com/rss/edition_asia.rss",
    "http://rss.cnn.com/rss/edition_europe.rss",
    "http://rss.cnn.com/rss/edition_meast.rss",
    "http://rss.cnn.com/rss/edition_us.rss",
    "http://feeds.feedburner.com/ndtvnews-india-news"
    ]

urls = [
    "https://www.smh.com.au/world/north-america/trump-administration-fuels-rumours-that-virus-came-from-china-lab-20200417-p54kr1.html"
    ]
